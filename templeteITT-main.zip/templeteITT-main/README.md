# templeteITT

memoria class

Se deja la plantilla del para el documento final de Residencia Profesional en LATEX, del DIEE del TecNM/IT de Tijuana.  Este templete fue realizado por el Dr. Miguel Aurelio Duarte Villaseñor, actualizado en abril de 2023.

El archivo memoria.tex es el principal, este es el que se debe correr en el LATEX, el llamará a los otros archivos cuando sea necesario. En memoria.tex llenar los datos usados en el documento (título, nombre, matricula, etc.).
El resumen se realiza en: resumen.tex; como buena práctica esto es lo último que se realizará del reporte. Los capítulo 1, 2, 3 y 4 se realizan en: cap1.tex, cap2.tex, etc; respectivamente. Las referencias bibliográficas y de otros tipos en: referencias.tex y en anexo 1 en Anexo1.tex (si es necesario puede realizar más anexos.
Para insertar figuras recomiendo hacer una carpeta de imágenes, asi no se tiene un mejor orden en le trabajo.

Para trabajar este templete recominedo utilizar TeXnicCenter, pero igual funciona con otros programas de LaTex.

IMPORTANTE: A todos estos archivos los llamará memoria.tex para entregar el documento final, no se compilan los capítulos por separado.
